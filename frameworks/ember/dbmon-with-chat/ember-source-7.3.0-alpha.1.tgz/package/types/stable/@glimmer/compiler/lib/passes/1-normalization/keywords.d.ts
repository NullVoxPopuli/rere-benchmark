declare module '@glimmer/compiler/lib/passes/1-normalization/keywords' {
    export { APPEND_KEYWORDS } from "@glimmer/compiler/lib/passes/1-normalization/keywords/append";
    export { BLOCK_KEYWORDS } from "@glimmer/compiler/lib/passes/1-normalization/keywords/block";
    export { CALL_KEYWORDS } from "@glimmer/compiler/lib/passes/1-normalization/keywords/call";
    export { MODIFIER_KEYWORDS } from "@glimmer/compiler/lib/passes/1-normalization/keywords/modifier";
}