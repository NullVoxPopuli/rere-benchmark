declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/append' {
    export const APPEND_KEYWORDS: import("@glimmer/compiler/lib/passes/1-normalization/keywords/impl").Keywords<"Append", never>;
}