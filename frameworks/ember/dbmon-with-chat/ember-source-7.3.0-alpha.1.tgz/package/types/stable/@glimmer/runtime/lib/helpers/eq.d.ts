declare module '@glimmer/runtime/lib/helpers/eq' {
    /**
     * Performs a strict equality comparison.
     *
     * left === right
     */
    export function eq(left: unknown, right: unknown): boolean;
}