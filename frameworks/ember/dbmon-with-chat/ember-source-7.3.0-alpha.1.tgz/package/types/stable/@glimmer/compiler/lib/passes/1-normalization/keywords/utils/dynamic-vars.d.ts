declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/utils/dynamic-vars' {
    import type * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import type { GenericKeywordNode, KeywordDelegate } from "@glimmer/compiler/lib/passes/1-normalization/keywords/impl";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export const getDynamicVarKeyword: KeywordDelegate<GenericKeywordNode, ASTv2.ExpressionNode, mir.GetDynamicVar>;
}