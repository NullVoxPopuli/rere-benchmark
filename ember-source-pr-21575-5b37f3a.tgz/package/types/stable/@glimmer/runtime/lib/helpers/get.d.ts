declare module '@glimmer/runtime/lib/helpers/get' {
    export const get: object;
}