declare module '@ember/-internals/utils/lib/microtask-scheduling' {
    /**
     * SPIKE (runloop removal): the minimal scheduling vocabulary the
     * framework actually needed from the runloop, rebuilt on microtasks.
     * Rendering no longer flushes at runloop end, so "later in this loop"
     * semantics collapse to "on a microtask" -- batched behind the current
     * task's synchronous work, ahead of the scheduler's next tick.
     */
    /**
     * `once(target, method)` replacement: coalesces repeat requests for the
     * same (target, method) until the scheduled microtask runs.
     */
    export function scheduleMethodOnce(target: object, method: PropertyKey): void;
    export interface CancelableMicrotask {
        cancelled: boolean;
    }
    /**
     * `scheduleOnce` + `cancel` replacement for one-shot deferred work.
     */
    export function scheduleCancelableMicrotask(fn: () => void): CancelableMicrotask;
}