declare module '@ember/-internals/metal/lib/decorator-util' {
    export type ClassMethodDecorator = (value: Function, context: ClassMethodDecoratorContext) => Function | void;
    export type ClassGetterDecorator = (value: Function, context: ClassGetterDecoratorContext) => Function | void;
    export type ClassSetterDecorator = (value: Function, context: ClassSetterDecoratorContext) => Function | void;
    export type ClassFieldDecorator = (value: undefined, context: ClassFieldDecoratorContext) => (initialValue: unknown) => unknown | void;
    export type ClassDecorator = (value: Function, context: ClassDecoratorContext) => Function | void;
    export type ClassAutoAccessorDecorator = (value: ClassAccessorDecoratorTarget<unknown, unknown>, context: ClassAccessorDecoratorContext) => ClassAccessorDecoratorResult<unknown, unknown>;
    export type Decorator = ClassMethodDecorator | ClassGetterDecorator | ClassSetterDecorator | ClassFieldDecorator | ClassDecorator | ClassAutoAccessorDecorator;
    export type StandardFieldDecorator = (value: undefined, context: ClassFieldDecoratorContext<any, any>) => void;
    export type StandardAccessorDecorator = <This, Value>(value: ClassAccessorDecoratorTarget<This, Value>, context: ClassAccessorDecoratorContext<This, Value>) => void;
    export type StandardGetterDecorator = (value: (this: any) => any, context: ClassGetterDecoratorContext<any, any>) => void;
    export type StandardSetterDecorator = (value: (this: any, value: any) => void, context: ClassSetterDecoratorContext<any, any>) => void;
    export type StandardMethodDecorator = (value: (this: any, ...args: any[]) => any, context: ClassMethodDecoratorContext<any, any>) => void;
    /**
      A decorator for class fields, which works with both legacy
      (`experimentalDecorators`) and standard decorators.
    */
    export type FieldDecorator = PropertyDecorator & StandardFieldDecorator;
    /**
      The decorator returned by `service()`, `inject()`, etc. Works on fields with
      both legacy and standard decorators, and on auto-accessors with standard
      decorators.
    */
    export type InjectionDecorator = FieldDecorator & StandardAccessorDecorator;
    export function isModernDecoratorArgs(args: unknown[]): args is Parameters<Decorator>;
    export function identifyModernDecoratorArgs(args: Parameters<Decorator>): {
        kind: "method";
        value: Parameters<ClassMethodDecorator>[0];
        context: Parameters<ClassMethodDecorator>[1];
    } | {
        kind: "getter";
        value: Parameters<ClassGetterDecorator>[0];
        context: Parameters<ClassGetterDecorator>[1];
    } | {
        kind: "setter";
        value: Parameters<ClassSetterDecorator>[0];
        context: Parameters<ClassSetterDecorator>[1];
    } | {
        kind: "field";
        value: Parameters<ClassFieldDecorator>[0];
        context: Parameters<ClassFieldDecorator>[1];
    } | {
        kind: "class";
        value: Parameters<ClassDecorator>[0];
        context: Parameters<ClassDecorator>[1];
    } | {
        kind: "accessor";
        value: Parameters<ClassAutoAccessorDecorator>[0];
        context: Parameters<ClassAutoAccessorDecorator>[1];
    };
    interface DecoratorContextWithMetadata {
        readonly name: string | symbol;
        readonly static?: boolean;
        readonly metadata: DecoratorMetadataObject;
        addInitializer(initializer: (this: any) => void): void;
    }
    export function onClassFinalized(context: DecoratorContextWithMetadata, setup: (target: object) => void): void;
    export function finalizeDecoratedClass(klass: Function): void;
    export {};
}