declare module '@glimmer/runtime/lib/opcodes' {
    import type { DebugOp } from "@glimmer/debug/lib/debug";
    import type { DebugVmSnapshot, Dict, Nullable, Optional, RuntimeOp, VmMachineOp, VmOp } from "@glimmer/interfaces";
    import { VmSnapshot } from "@glimmer/debug/lib/vm/snapshot";
    import type { VM } from "@glimmer/runtime/lib/vm";
    import type { Externs } from "@glimmer/runtime/lib/vm/low-level";
    export interface OpcodeJSON {
        type: number | string;
        guid?: Nullable<number>;
        deopted?: boolean;
        args?: string[];
        details?: Dict<Nullable<string>>;
        children?: OpcodeJSON[];
    }
    export type Operand1 = number;
    export type Operand2 = number;
    export type Operand3 = number;
    export type Syscall = (vm: VM, opcode: RuntimeOp) => void;
    export type DebugState = {
        opcode: {
            type: VmMachineOp | VmOp;
            isMachine: 0 | 1;
            size: number;
        };
        closeGroup?: undefined | (() => void);
        op?: Optional<DebugOp>;
        debug: DebugVmSnapshot;
        snapshot: VmSnapshot;
    };
    export class AppendOpcodes {
        private evaluateOpcode;
        debugBefore?: (vm: DebugVmSnapshot, opcode: RuntimeOp) => DebugState;
        debugAfter?: (debug: DebugVmSnapshot, pre: DebugState) => void;
        constructor();
        add<Name extends VmOp>(name: Name, evaluate: Syscall): void;
        evaluate(vm: VM, opcode: RuntimeOp, type: number): void;
    }
    export function externs(vm: VM): Externs | undefined;
    export const APPEND_OPCODES: AppendOpcodes;
}