declare module '@glimmer/runtime/lib/helpers/hash' {
    export const hash: object;
}