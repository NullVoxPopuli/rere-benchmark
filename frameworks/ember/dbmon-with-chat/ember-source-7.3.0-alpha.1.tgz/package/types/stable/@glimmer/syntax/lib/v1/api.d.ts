declare module '@glimmer/syntax/lib/v1/api' {
    export type { SourcePosition as Position, SourceLocation, SourcePosition } from "@glimmer/syntax/lib/source/api";
    export type * from "@glimmer/syntax/lib/v1/nodes-v1";
}