declare module '@glimmer/vm/lib/content' {
    export const ContentType: {
        readonly Component: 0;
        readonly Helper: 1;
        readonly String: 2;
        readonly Empty: 3;
        readonly SafeString: 4;
        readonly Fragment: 5;
        readonly Node: 6;
        readonly Other: 8;
    };
}