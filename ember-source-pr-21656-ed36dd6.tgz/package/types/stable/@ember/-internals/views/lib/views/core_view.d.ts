declare module '@ember/-internals/views/lib/views/core_view' {
    import type { Renderer, View } from "@ember/-internals/glimmer/lib/renderer";
    import ActionHandler from "@ember/-internals/runtime/lib/mixins/action_handler";
    import type { ViewState } from "@ember/-internals/views/lib/views/states";
    import states from "@ember/-internals/views/lib/views/states";
    /**
      `CoreView` is an abstract class that exists to give view-like behavior
      to both Ember's main view class `Component` and other classes that don't need
      the full functionality of `Component`.

      Unless you have specific needs for `CoreView`, you will use `Component`
      in your applications.

      @class CoreView
      @namespace Ember
      @extends EmberObject
      @deprecated Use `Component` instead.
      @uses Evented
      @uses Ember.ActionHandler
      @private
    */
    interface CoreView extends ActionHandler, View {
    }
    const CoreView_base: Readonly<typeof import("@ember/object").default> & (new (owner?: import("@ember/owner").default) => import("@ember/object").default) & import("@ember/object/mixin").default;
    class CoreView extends CoreView_base {
        isView: boolean;
        _states: typeof states;
        _state: keyof typeof states;
        _currentState: ViewState;
        /**
          If the view is currently inserted into the DOM of a parent view, this
          property will point to the parent of the view.
      
          @property parentView
          @type Ember.View
          @default null
          @private
        */
        parentView: View | null;
        init(properties: object | undefined): void;
        renderer: Renderer;
        instrumentDetails(hash: Record<string, unknown>): Record<string, unknown>;
        on<Target>(name: string, target: Target, method: string | ((this: Target, ...args: any[]) => void)): this;
        on(name: string, method: ((...args: any[]) => void) | string): this;
        one<Target>(name: string, target: Target, method: string | ((this: Target, ...args: any[]) => void)): this;
        one(name: string, method: string | ((...args: any[]) => void)): this;
        /**
          Override the default event firing from `Evented` to
          also call methods with the given name.
      
          @method trigger
          @param name {String}
          @private
        */
        trigger(name: string, ...args: any[]): any;
        off<Target>(name: string, target: Target, method: string | ((this: Target, ...args: any[]) => void)): this;
        off(name: string, method: string | ((...args: any[]) => void)): this;
        has(name: string): boolean;
        static isViewFactory: boolean;
    }
    export default CoreView;
}