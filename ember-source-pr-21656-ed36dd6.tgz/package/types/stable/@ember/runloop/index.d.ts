declare module '@ember/runloop' {
    /**
      SPIKE (backburner removal): the run loop is gone. What remains here is
      a dependency-free compatibility surface so the module specifier keeps
      resolving: `run`/`join`/`bind` are plain calls, queues collapse to
      microtasks, and timers are native timers. Rendering is driven by
      `@ember/scheduler`; nothing in the framework schedules through this
      module anymore.

      @module @ember/runloop
      @public
    */
    import type { AnyFn } from "@ember/-internals/utility-types";
    type PartialParams<P extends any[]> = P extends [infer First, ...infer Rest] ? [] | [First] | [First, ...PartialParams<Rest>] : Required<P> extends [infer First, ...infer Rest] ? [] | [First | undefined] | [First | undefined, ...PartialParams<Partial<Rest>>] : [];
    type RemainingParams<PartialParams extends any[], All extends any[]> = PartialParams extends [
        infer First,
        ...infer Rest
    ] ? All extends [infer AllFirst, ...infer AllRest] ? First extends AllFirst ? RemainingParams<Rest, AllRest> : never : Required<All> extends [infer AllFirst, ...infer AllRest] ? First extends AllFirst | undefined ? Partial<RemainingParams<Rest, AllRest>> : never : never : PartialParams extends [] ? All : never;
    export interface Timeout {
        kind: "timeout";
        id: ReturnType<typeof setTimeout>;
    }
    export interface Microtask {
        kind: "microtask";
        cancelled: boolean;
    }
    export type Timer = Timeout | Microtask;
    /**
      Runs the passed function immediately. With no run loop, this is a
      plain call.

      @method run
      @for @ember/runloop
      @static
      @public
    */
    export function run<F extends () => any>(method: F): ReturnType<F>;
    export function run<F extends AnyFn>(method: F, ...args: Parameters<F>): ReturnType<F>;
    export function run<T, F extends (this: T, ...args: any[]) => any>(target: T, method: F, ...args: Parameters<F>): ReturnType<F>;
    export function run<T, U extends keyof T>(target: T, method: U, ...args: T[U] extends AnyFn ? Parameters<T[U]> : []): T[U] extends AnyFn ? ReturnType<T[U]> : unknown;
    /**
      Runs the passed function immediately, joining any conceptual ongoing
      work. With no run loop, this is a plain call.

      @method join
      @for @ember/runloop
      @static
      @public
    */
    export function join<F extends AnyFn>(method: F, ...args: Parameters<F>): ReturnType<F> | void;
    export function join<T, F extends (this: T, ...args: any[]) => any>(target: T, method: F, ...args: Parameters<F>): ReturnType<F> | void;
    export function join<T, U extends keyof T>(target: T, method: U, ...args: T[U] extends AnyFn ? Parameters<T[U]> : []): T[U] extends AnyFn ? ReturnType<T[U]> | void : void;
    /**
      Returns a function bound to the given target and arguments. With no
      run loop there is nothing to wrap; this is `Function#bind` with
      string-method resolution.

      @method bind
      @for @ember/runloop
      @static
      @public
    */
    export function bind<T, F extends (this: T, ...args: any[]) => any, A extends PartialParams<Parameters<F>>>(target: T, method: F, ...args: A): (...args: RemainingParams<A, Parameters<F>>) => ReturnType<F> | void;
    export function bind<F extends AnyFn, A extends PartialParams<Parameters<F>>>(method: F, ...args: A): (...args: RemainingParams<A, Parameters<F>>) => ReturnType<F> | void;
    export function bind<T, U extends keyof T, A extends T[U] extends AnyFn ? PartialParams<Parameters<T[U]>> : []>(target: T, method: U, ...args: A): T[U] extends AnyFn ? (...args: RemainingParams<A, Parameters<T[U]>>) => ReturnType<T[U]> | void : never;
    export function bind<T, M extends keyof T & PropertyKey>(target: T, methodName: M, ...args: any[]): (...args: any[]) => unknown;
    /**
      Begins a run loop. With no run loop, this is a no-op.

      @method begin
      @for @ember/runloop
      @static
      @public
    */
    export function begin(): void;
    /**
      Ends a run loop. With no run loop, this is a no-op.

      @method end
      @for @ember/runloop
      @static
      @public
    */
    export function end(): void;
    /**
      Schedules work onto a queue. Queues collapse to the microtask queue:
      work runs after the current synchronous execution, in scheduling
      order.

      @method schedule
      @for @ember/runloop
      @static
      @public
    */
    export function schedule<F extends AnyFn>(queueName: string, method: F, ...args: Parameters<F>): Timer;
    export function schedule<T, F extends (this: T, ...args: any[]) => any>(queueName: string, target: T, method: F, ...args: Parameters<F>): Timer;
    export function schedule<T, U extends keyof T>(
      queueName: string,
      target: T,
      method: U,
      ...args: T[U] extends AnyFn ? Parameters<T[U]> : []
    ): Timer;
    /**
      Schedules work onto a queue, coalescing repeat requests for the same
      target and method until the scheduled microtask runs.

      @method scheduleOnce
      @for @ember/runloop
      @static
      @public
    */
    export function scheduleOnce<F extends AnyFn>(queueName: string, method: F, ...args: Parameters<F>): Timer;
    export function scheduleOnce<T, F extends (this: T, ...args: any[]) => any>(queueName: string, target: T, method: F, ...args: Parameters<F>): Timer;
    export function scheduleOnce<T, U extends keyof T>(
      queueName: string,
      target: T,
      method: U,
      ...args: T[U] extends AnyFn ? Parameters<T[U]> : []
    ): Timer;
    /**
      Schedules work to run once, coalescing repeat requests for the same
      target and method.

      @method once
      @for @ember/runloop
      @static
      @public
    */
    export function once<F extends AnyFn>(method: F, ...args: Parameters<F>): Timer;
    export function once<T, F extends (this: T, ...args: any[]) => any>(target: T, method: F, ...args: Parameters<F>): Timer;
    export function once<T, U extends keyof T>(target: T, method: U, ...args: T[U] extends AnyFn ? Parameters<T[U]> : []): Timer;
    /**
      Runs the passed function in the next task.

      @method next
      @for @ember/runloop
      @static
      @public
    */
    export function next<F extends AnyFn>(method: F, ...args: Parameters<F>): Timer;
    export function next<T, F extends (this: T, ...args: any[]) => any>(target: T, method: F, ...args: Parameters<F>): Timer;
    export function next<T, U extends keyof T>(target: T, method: U, ...args: T[U] extends AnyFn ? Parameters<T[U]> : []): Timer;
    /**
      Runs the passed function after the given number of milliseconds.

      @method later
      @for @ember/runloop
      @static
      @public
    */
    export function later<T, F extends (this: T, ...args: any[]) => any>(
      target: T,
      method: F,
      ...args: [...args: Parameters<F>, wait: string | number]
    ): Timer;
    export function later<F extends AnyFn>(method: F, ...args: [...args: Parameters<F>, wait: string | number]): Timer;
    export function later<T, U extends keyof T>(
      target: T,
      method: U,
      ...args: [...args: T[U] extends AnyFn ? Parameters<T[U]> : [], wait: string | number]
    ): Timer;
    /**
      Debounces the passed function by the given number of milliseconds.

      @method debounce
      @for @ember/runloop
      @static
      @public
    */
    export function debounce<F extends AnyFn>(
      method: F,
      ...args: [...args: Parameters<F>, wait: string | number, immediate?: boolean]
    ): Timer;
    export function debounce<T, F extends (this: T, ...args: any[]) => any>(
      target: T,
      method: F,
      ...args: [...args: Parameters<F>, wait: string | number, immediate?: boolean]
    ): Timer;
    export function debounce<T, U extends keyof T>(
      target: T,
      method: U,
      ...args: [
          ...args: T[U] extends AnyFn ? Parameters<T[U]> : [],
          wait: string | number,
          immediate?: boolean
      ]
    ): Timer;
    /**
      Throttles the passed function to at most once per the given number of
      milliseconds.

      @method throttle
      @for @ember/runloop
      @static
      @public
    */
    export function throttle<F extends AnyFn>(
      method: F,
      ...args: [...args: Parameters<F>, wait?: string | number, immediate?: boolean]
    ): Timer;
    export function throttle<T, F extends (this: T, ...args: any[]) => any>(
      target: T,
      method: F,
      ...args: [...args: Parameters<F>, wait?: string | number, immediate?: boolean]
    ): Timer;
    export function throttle<T, U extends keyof T>(
      target: T,
      method: U,
      ...args: [
          ...args: T[U] extends AnyFn ? Parameters<T[U]> : [],
          wait?: string | number,
          immediate?: boolean
      ]
    ): Timer;
    /**
      Cancels a timer returned from `later`, `next`, `once`, `schedule`,
      `scheduleOnce`, `debounce`, or `throttle`.

      @method cancel
      @for @ember/runloop
      @static
      @public
    */
    export function cancel(timer?: Timer): boolean;
    export function _getCurrentRunLoop(): null;
    export function _hasScheduledTimers(): boolean;
    export function _cancelTimers(): void;
    export {};
}