declare module '@glimmer/syntax/lib/traversal/-index' {
    export { cannotRemoveNode, cannotReplaceNode, cannotReplaceOrRemoveInKeyHandlerYet, } from "@glimmer/syntax/lib/traversal/errors";
    export { default as WalkerPath } from "@glimmer/syntax/lib/traversal/path";
    export { default as traverse } from "@glimmer/syntax/lib/traversal/traverse";
    export type { NodeVisitor } from "@glimmer/syntax/lib/traversal/visitor";
    export { default as Walker } from "@glimmer/syntax/lib/traversal/walker";
}