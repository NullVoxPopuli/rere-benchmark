declare module '@ember/template-compiler/-internal-utils' {
    export * from "@ember/template-compiler/lib/plugins/utils";
}