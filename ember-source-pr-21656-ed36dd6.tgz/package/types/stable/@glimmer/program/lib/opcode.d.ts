declare module '@glimmer/program/lib/opcode' {
    import type { ProgramHeap, RuntimeOp, SomeVmOp } from "@glimmer/interfaces";
    /**
     * A cursor over the program heap
     */
    export class RuntimeOpImpl implements RuntimeOp {
        readonly heap: ProgramHeap;
        offset: number;
        type: SomeVmOp;
        size: number;
        isMachine: 0 | 1;
        constructor(heap: ProgramHeap);
        /**
         * decodes the header word once,
         *   because the VM reads `type`, `size` and `isMachine` for every instruction.
         */
        seek(offset: number): this;
        get op1(): number;
        get op2(): number;
        get op3(): number;
    }
}