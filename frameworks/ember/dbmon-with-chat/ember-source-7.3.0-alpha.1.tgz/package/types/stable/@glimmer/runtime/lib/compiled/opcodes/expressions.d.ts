declare module '@glimmer/runtime/lib/compiled/opcodes/expressions' {
    export {};
}