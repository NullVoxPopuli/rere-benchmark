declare module '@ember/template-factory' {
    export { default as createTemplateFactory } from "@glimmer/opcode-compiler/lib/template";
}