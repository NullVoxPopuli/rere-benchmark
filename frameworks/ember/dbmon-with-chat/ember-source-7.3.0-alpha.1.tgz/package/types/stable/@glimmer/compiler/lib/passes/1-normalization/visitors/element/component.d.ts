declare module '@glimmer/compiler/lib/passes/1-normalization/visitors/element/component' {
    import type * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import type { Result } from "@glimmer/compiler/lib/shared/result";
    import type { Classified, ClassifiedElement, PreparedArgs } from "@glimmer/compiler/lib/passes/1-normalization/visitors/element/classified";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export class ClassifiedComponent implements Classified {
        private tag;
        private element;
        readonly dynamicFeatures = true;
        constructor(tag: mir.ExpressionNode, element: ASTv2.InvokeComponent);
        arg(attr: ASTv2.ComponentArg, { state }: ClassifiedElement): Result<mir.NamedArgument>;
        toStatement(component: ClassifiedElement, { args, params }: PreparedArgs): Result<mir.Statement>;
        private blocks;
    }
}