declare module '@glimmer/interfaces/lib/managers' {
    export type * from "@glimmer/interfaces/lib/managers/capabilities";
    export type * from "@glimmer/interfaces/lib/managers/component";
    export type * from "@glimmer/interfaces/lib/managers/helper";
    export type * from "@glimmer/interfaces/lib/managers/internal";
    export type * from "@glimmer/interfaces/lib/managers/modifier";
}