declare module '@glimmer/runtime/lib/helpers/concat' {
    export const concat: object;
}