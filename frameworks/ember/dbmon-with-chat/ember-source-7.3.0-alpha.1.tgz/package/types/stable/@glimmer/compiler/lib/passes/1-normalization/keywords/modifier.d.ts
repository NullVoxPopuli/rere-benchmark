declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/modifier' {
    export const MODIFIER_KEYWORDS: import("@glimmer/compiler/lib/passes/1-normalization/keywords/impl").Keywords<"Modifier", never>;
}