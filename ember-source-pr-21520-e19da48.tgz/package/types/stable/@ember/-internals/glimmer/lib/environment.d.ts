declare module '@ember/-internals/glimmer/lib/environment' {
    import type { InternalOwner } from "@ember/-internals/owner";
    import type { EnvironmentDelegate } from "@glimmer/runtime/lib/environment";
    export function _setNotifyRevalidate(fn: () => boolean): void;
    export function _resetInvalidationNotified(): void;
    /**
     * Runs pending destructors, then finalizers -- the classic
     * actions-before-destroy queue ordering. Destruction can schedule
     * further destruction, so drain until quiet.
     */
    export function _drainScheduledDestroys(): void;
    export class EmberEnvironmentDelegate implements EnvironmentDelegate {
        owner: InternalOwner;
        isInteractive: boolean;
        enableDebugTooling: boolean;
        constructor(owner: InternalOwner, isInteractive: boolean);
        onTransactionCommit(): void;
    }
}