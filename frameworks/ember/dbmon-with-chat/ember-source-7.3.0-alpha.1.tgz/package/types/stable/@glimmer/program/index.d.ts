declare module '@glimmer/program' {
    export * from "@glimmer/program/lib/constants";
    export * from "@glimmer/program/lib/helpers";
    export * from "@glimmer/program/lib/opcode";
    export * from "@glimmer/program/lib/program";
}