declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/block' {
    export const BLOCK_KEYWORDS: import("@glimmer/compiler/lib/passes/1-normalization/keywords/impl").Keywords<"Block", never>;
}