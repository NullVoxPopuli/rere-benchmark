declare module '@ember/template-compiler/lib/system/calculate-location-display' {
    import type * as AST from "@glimmer/syntax/lib/v1/api";
    export default function calculateLocationDisplay(moduleName: string | undefined, loc?: AST.SourceLocation | undefined): string;
}