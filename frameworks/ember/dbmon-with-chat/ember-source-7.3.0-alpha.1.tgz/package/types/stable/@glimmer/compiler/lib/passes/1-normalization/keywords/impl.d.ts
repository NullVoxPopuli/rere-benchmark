declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/impl' {
    import type * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import type { KeywordType } from "@glimmer/syntax/lib/keywords";
    import type { Result } from "@glimmer/compiler/lib/shared/result";
    import type { NormalizationState } from "@glimmer/compiler/lib/passes/1-normalization/context";
    export interface KeywordDelegate<Match extends KeywordMatch, V, Out> {
        assert: (options: Match, state: NormalizationState) => Result<V>;
        translate: (options: {
            node: Match;
            state: NormalizationState;
        }, param: V) => Result<Out>;
    }
    export interface Keyword<K extends KeywordType = KeywordType, Out = unknown> {
        translate(node: KeywordCandidates[K], state: NormalizationState): Result<Out> | null;
    }
    export interface BlockKeyword<Out = unknown> {
        translate(node: ASTv2.InvokeBlock, state: NormalizationState): Result<Out> | null;
    }
    export const KEYWORD_NODES: {
        readonly Call: readonly ["Call"];
        readonly Block: readonly ["InvokeBlock"];
        readonly Append: readonly ["AppendContent"];
        readonly Modifier: readonly ["ElementModifier"];
    };
    export interface KeywordCandidates {
        Call: ASTv2.ExpressionNode;
        Block: ASTv2.InvokeBlock;
        Append: ASTv2.AppendContent;
        Modifier: ASTv2.ElementModifier;
    }
    export type KeywordCandidate = KeywordCandidates[keyof KeywordCandidates];
    export interface KeywordMatches {
        Call: ASTv2.CallExpression;
        Block: ASTv2.InvokeBlock;
        Append: ASTv2.AppendContent;
        Modifier: ASTv2.ElementModifier;
    }
    export type KeywordMatch = KeywordMatches[keyof KeywordMatches];
    /**
     * A "generic" keyword is something like `has-block`, which makes sense in the context
     * of sub-expression or append
     */
    export type GenericKeywordNode = ASTv2.AppendContent | ASTv2.CallExpression;
    export type KeywordNode = GenericKeywordNode | ASTv2.CallExpression | ASTv2.InvokeBlock | ASTv2.ElementModifier;
    export type PossibleKeyword = KeywordNode;
    type OutFor<K extends Keyword | BlockKeyword> = K extends BlockKeyword<infer Out> ? Out : K extends Keyword<KeywordType, infer Out> ? Out : never;
    export class Keywords<K extends KeywordType, KeywordList extends Keyword<K> = never> implements Keyword<K, OutFor<KeywordList>> {
        _keywords: Keyword[];
        _type: K;
        constructor(type: K);
        kw<V, S extends string = string, Out = unknown>(name: S, delegate: KeywordDelegate<KeywordMatches[K], V, Out>): this;
        translate(node: KeywordCandidates[K], state: NormalizationState): Result<OutFor<KeywordList>> | null;
    }
    /**
     * This function builds keyword definitions for a particular type of AST node (`KeywordType`).
     *
     * You can build keyword definitions for:
     *
     * - `Expr`: A `SubExpression` or `PathExpression`
     * - `Block`: A `BlockStatement`
     *   - A `BlockStatement` is a keyword candidate if its head is a
     *     `PathExpression`
     * - `Append`: An `AppendStatement`
     *
     * A node is a keyword candidate if:
     *
     * - A `PathExpression` is a keyword candidate if it has no tail, and its
     *   head expression is a `LocalVarHead` or `FreeVarHead` whose name is
     *   the keyword's name.
     * - A `SubExpression`, `AppendStatement`, or `BlockStatement` is a keyword
     *   candidate if its head is a keyword candidate.
     *
     * The keyword infrastructure guarantees that:
     *
     * - If a node is not a keyword candidate, it is never passed to any keyword's
     *   `assert` method.
     * - If a node is not the `KeywordType` for a particular keyword, it will not
     *   be passed to the keyword's `assert` method.
     *
     * `Expr` keywords are used in expression positions and should return HIR
     * expressions. `Block` and `Append` keywords are used in statement
     * positions and should return HIR statements.
     *
     * A keyword definition has two parts:
     *
     * - `match`, which determines whether an AST node matches the keyword, and can
     *   optionally return some information extracted from the AST node.
     * - `translate`, which takes a matching AST node as well as the extracted
     *   information and returns an appropriate HIR instruction.
     *
     * # Example
     *
     * This keyword:
     *
     * - turns `(hello)` into `"hello"`
     *   - as long as `hello` is not in scope
     * - makes it an error to pass any arguments (such as `(hello world)`)
     *
     * ```ts
     * keywords('SubExpr').kw('hello', {
     *   assert(node: ExprKeywordNode): Result<void> | false {
     *     // we don't want to transform `hello` as a `PathExpression`
     *     if (node.type !== 'SubExpression') {
     *       return false;
     *     }
     *
     *     // node.head would be `LocalVarHead` if `hello` was in scope
     *     if (node.head.type !== 'FreeVarHead') {
     *       return false;
     *     }
     *
     *     if (node.params.length || node.hash) {
     *       return Err(generateSyntaxError(`(hello) does not take any arguments`), node.loc);
     *     } else {
     *       return Ok();
     *     }
     *   },
     *
     *   translate(node: ASTv2.SubExpression): hir.Expression {
     *     return ASTv2.builders.literal("hello", node.loc)
     *   }
     * })
     * ```
     *
     * The keyword infrastructure checks to make sure that the node is the right
     * type before calling `assert`, so you only need to consider `SubExpression`
     * and `PathExpression` here. It also checks to make sure that the node passed
     * to `assert` has the keyword name in the right place.
     *
     * Note the important difference between returning `false` from `assert`,
     * which just means that the node didn't match, and returning `Err`, which
     * means that the node matched, but there was a keyword-specific syntax
     * error.
     */
    export function keywords<K extends KeywordType>(type: K): Keywords<K>;
    export {};
}