declare module '@glimmer/validator/lib/meta' {
    import type { ConstantTag, UpdatableTag } from "@glimmer/interfaces";
    export type TagMeta = Map<PropertyKey, UpdatableTag>;
    /**
     * Read-only registry lookup: the canonical tag for (obj, key) if one
     * exists, with no create-on-miss allocation.
     */
    export function peekTagFor(obj: object, key: PropertyKey): UpdatableTag | undefined;
    /**
     * Adopts an externally-owned tag (e.g. a tracked field's inline cell
     * tag) as THE tag for (obj, key) in the central registry, so
     * `tagFor`/`dirtyTagFor` consumers -- notifyPropertyChange, computed
     * property chains -- observe the same tag object the field itself
     * consumes and dirties.
     */
    export function registerTagFor(obj: object, key: PropertyKey, tag: UpdatableTag): void;
    export function dirtyTagFor<T extends object>(obj: T, key: keyof T | string | symbol, meta?: TagMeta): void;
    export function tagMetaFor(obj: object): TagMeta;
    export function tagFor<T extends object>(obj: T, key: keyof T | string | symbol, meta?: TagMeta): UpdatableTag | ConstantTag;
}