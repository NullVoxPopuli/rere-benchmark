declare module 'ember-template-compiler/lib/plugins' {
    import type { ASTPluginBuilder } from "@glimmer/syntax";
    export const INTERNAL_PLUGINS: Record<string, ASTPluginBuilder>;
    export const RESOLUTION_MODE_TRANSFORMS: readonly ASTPluginBuilder[];
    export const STRICT_MODE_TRANSFORMS: readonly ASTPluginBuilder[];
    export const STRICT_MODE_KEYWORDS: readonly string[];
}