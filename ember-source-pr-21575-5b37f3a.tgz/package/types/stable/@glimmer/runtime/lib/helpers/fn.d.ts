declare module '@glimmer/runtime/lib/helpers/fn' {
    export const fn: object;
}